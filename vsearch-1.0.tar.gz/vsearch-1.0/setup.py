from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The head first python search tools',
    author='I',
    author_email='1@mail.ru',
    url='google.com',
    py_modules=['vsearch'],
)